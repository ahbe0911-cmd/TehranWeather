# Add project specific ProGuard rules here.
-keep class com.example.tehranweather.model.** { *; }
