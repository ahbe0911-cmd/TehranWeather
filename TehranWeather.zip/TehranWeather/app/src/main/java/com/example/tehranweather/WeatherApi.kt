package com.example.tehranweather

import com.google.gson.annotations.SerializedName
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class WeatherResponse(
    @SerializedName("current_weather") val currentWeather: CurrentWeather?,
    @SerializedName("hourly") val hourly: HourlyData?
)

data class CurrentWeather(
    @SerializedName("temperature") val temperature: Double,
    @SerializedName("windspeed") val windSpeed: Double,
    @SerializedName("winddirection") val windDirection: Double,
    @SerializedName("weathercode") val weatherCode: Int,
    @SerializedName("time") val time: String
)

data class HourlyData(
    @SerializedName("time") val time: List<String>,
    @SerializedName("temperature_2m") val temperature2m: List<Double>,
    @SerializedName("relative_humidity_2m") val relativeHumidity2m: List<Int>,
    @SerializedName("precipitation_probability") val precipitationProbability: List<Int>,
    @SerializedName("surface_pressure") val surfacePressure: List<Double>,
    @SerializedName("apparent_temperature") val apparentTemperature: List<Double>,
    @SerializedName("weathercode") val weatherCode: List<Int>
)

interface WeatherApiService {
    @GET("v1/forecast")
    suspend fun getForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current_weather") currentWeather: Boolean = true,
        @Query("hourly") hourly: String =
            "temperature_2m,relative_humidity_2m,precipitation_probability,surface_pressure,apparent_temperature,weathercode",
        @Query("timezone") timezone: String = "auto"
    ): WeatherResponse
}

object WeatherApi {
    val service: WeatherApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.open-meteo.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(WeatherApiService::class.java)
    }

    /** Maps Open-Meteo WMO weather codes to a local drawable icon resource. */
    fun iconForCode(code: Int): Int = when (code) {
        0 -> R.drawable.ic_sun
        1, 2 -> R.drawable.ic_cloud_sun
        3 -> R.drawable.ic_cloud
        45, 48 -> R.drawable.ic_cloud
        51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> R.drawable.ic_rain
        71, 73, 75, 77, 85, 86 -> R.drawable.ic_snow
        95, 96, 99 -> R.drawable.ic_rain
        else -> R.drawable.ic_cloud
    }
}
