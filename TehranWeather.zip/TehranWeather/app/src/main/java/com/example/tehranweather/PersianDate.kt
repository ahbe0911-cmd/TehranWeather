package com.example.tehranweather

import java.util.Calendar

/**
 * Lightweight Gregorian -> Jalali (Solar Hijri) calendar converter.
 * No external library / network dependency required.
 */
object PersianDate {

    private val weekDays = arrayOf(
        "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"
    )

    private val monthNames = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    fun toPersianDigits(input: String): String {
        val sb = StringBuilder()
        for (c in input) {
            if (c in '0'..'9') sb.append(persianDigits[c - '0']) else sb.append(c)
        }
        return sb.toString()
    }

    data class Jalali(val year: Int, val month: Int, val day: Int)

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Jalali {
        val gDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gy2 = gy - 1600
        val gm2 = gm - 1
        val gd2 = gd - 1

        var gDayNo = 365 * gy2 + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400
        for (i in 0 until gm2) {
            gDayNo += gDaysInMonth[i]
        }
        if (gm2 > 1 && ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0))) {
            gDayNo += 1
        }
        gDayNo += gd2

        var jDayNo = gDayNo - 79

        val jNp = jDayNo / 12053
        jDayNo %= 12053

        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461

        if (jDayNo >= 366) {
            jy += (jDayNo - 1) / 365
            jDayNo = (jDayNo - 1) % 365
        }

        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)
        var jm = 0
        var i = 0
        while (i < 11 && jDayNo >= jDaysInMonth[i]) {
            jDayNo -= jDaysInMonth[i]
            i++
        }
        jm = i + 1
        val jd = jDayNo + 1

        return Jalali(jy, jm, jd.toInt())
    }

    /** Returns a full formatted Persian date string, e.g. "سه‌شنبه ۲۳ آبان ۱۴۰۳" */
    fun formatToday(): String {
        val cal = Calendar.getInstance()
        val gy = cal.get(Calendar.YEAR)
        val gm = cal.get(Calendar.MONTH) + 1
        val gd = cal.get(Calendar.DAY_OF_MONTH)
        val j = gregorianToJalali(gy, gm, gd)

        // Calendar.DAY_OF_WEEK: 1=Sunday ... 7=Saturday, matches our weekDays array order
        val dow = cal.get(Calendar.DAY_OF_WEEK) - 1
        val weekDay = weekDays[dow]
        val monthName = monthNames[j.month - 1]

        return "$weekDay ${toPersianDigits(j.day.toString())} $monthName ${toPersianDigits(j.year.toString())}"
    }
}
