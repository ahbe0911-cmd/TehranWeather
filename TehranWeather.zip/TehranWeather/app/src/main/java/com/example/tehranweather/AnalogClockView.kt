package com.example.tehranweather

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class AnalogClockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val persianNumerals = arrayOf(
        "۱۲", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹", "۱۰", "۱۱"
    )

    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
    }

    private val tickPaintMinor = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B9D9F2")
        strokeWidth = 3f
    }

    private val tickPaintMajor = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E9BF0")
        strokeWidth = 6f
    }

    private val numeralPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#16294D")
        textAlign = Paint.Align.CENTER
    }

    private val hourHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1C8FA6")
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
    }

    private val minuteHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D6316B")
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
    }

    private val secondHandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5A623")
        strokeWidth = 4f
        strokeCap = Paint.Cap.ROUND
    }

    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val centerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D9E4EE")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val ampmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7A8AA0")
        textAlign = Paint.Align.CENTER
    }

    private val digitalPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2E9BF0")
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val radius = min(w, h) / 2f * 0.94f

        borderPaint.strokeWidth = radius * 0.03f
        numeralPaint.textSize = radius * 0.16f
        ampmPaint.textSize = radius * 0.09f
        digitalPaint.textSize = radius * 0.135f

        // Face
        canvas.drawCircle(cx, cy, radius, facePaint)
        canvas.drawCircle(cx, cy, radius - borderPaint.strokeWidth / 2f, borderPaint)

        // Ticks
        for (i in 0 until 60) {
            val angle = Math.toRadians((i * 6).toDouble() - 90)
            val isMajor = i % 5 == 0
            val outerR = radius * 0.92f
            val innerR = if (isMajor) radius * 0.80f else radius * 0.86f
            val paint = if (isMajor) tickPaintMajor else tickPaintMinor
            val x1 = cx + (outerR * cos(angle)).toFloat()
            val y1 = cy + (outerR * sin(angle)).toFloat()
            val x2 = cx + (innerR * cos(angle)).toFloat()
            val y2 = cy + (innerR * sin(angle)).toFloat()
            canvas.drawLine(x1, y1, x2, y2, paint)
        }

        // Numerals
        val numeralR = radius * 0.68f
        for (i in 0 until 12) {
            val angle = Math.toRadians((i * 30).toDouble() - 90)
            val x = cx + (numeralR * cos(angle)).toFloat()
            val y = cy + (numeralR * sin(angle)).toFloat() - (numeralPaint.ascent() + numeralPaint.descent()) / 2f
            canvas.drawText(persianNumerals[i], x, y, numeralPaint)
        }

        // Current time
        val cal = Calendar.getInstance()
        val hour24 = cal.get(Calendar.HOUR_OF_DAY)
        val hour12 = cal.get(Calendar.HOUR)
        val minute = cal.get(Calendar.MINUTE)
        val second = cal.get(Calendar.SECOND)
        val isAm = hour24 < 12

        val hourAngle = Math.toRadians(((hour12 % 12) * 30 + minute * 0.5).toDouble() - 90)
        val minuteAngle = Math.toRadians((minute * 6).toDouble() - 90)
        val secondAngle = Math.toRadians((second * 6).toDouble() - 90)

        drawHand(canvas, cx, cy, hourAngle, radius * 0.45f, hourHandPaint)
        drawHand(canvas, cx, cy, minuteAngle, radius * 0.65f, minuteHandPaint)
        drawHand(canvas, cx, cy, secondAngle, radius * 0.72f, secondHandPaint)

        canvas.drawCircle(cx, cy, radius * 0.06f, centerPaint)
        canvas.drawCircle(cx, cy, radius * 0.06f, centerBorderPaint)

        // Digital sub-display (AM/PM + HH:MM:SS in Persian digits)
        val ampmText = if (isAm) "AM" else "PM"
        val timeText = PersianDate.toPersianDigits(
            String.format("%02d:%02d:%02d", hour12.let { if (it == 0) 12 else it }, minute, second)
        )
        val subY = cy + radius * 0.40f
        canvas.drawText(ampmText, cx, subY, ampmPaint)
        canvas.drawText(timeText, cx, subY + digitalPaint.textSize * 1.1f, digitalPaint)

        // Keep the clock ticking every second
        postInvalidateDelayed(1000)
    }

    private fun drawHand(canvas: Canvas, cx: Float, cy: Float, angle: Double, length: Float, paint: Paint) {
        val x = cx + (length * cos(angle)).toFloat()
        val y = cy + (length * sin(angle)).toFloat()
        canvas.drawLine(cx, cy, x, y, paint)
    }
}
