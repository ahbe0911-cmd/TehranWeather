package com.example.tehranweather

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.tehranweather.databinding.ActivityMainBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.location.CurrentLocationRequest
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    // Default location: Tehran, Iran
    private val defaultLat = 35.6892
    private val defaultLon = 51.3890
    private val defaultCityName = "تهران"

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            fetchDeviceLocationAndLoad()
        } else {
            Toast.makeText(this, getString(R.string.using_default_location), Toast.LENGTH_SHORT).show()
            loadWeather(defaultLat, defaultLon, defaultCityName)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        binding.tvDate.text = PersianDate.formatToday()
        binding.tvCityName.text = defaultCityName

        binding.rvHourly.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        binding.swipeRefresh.setOnRefreshListener {
            requestLocationAndLoad()
        }

        setupBottomNav()
        requestLocationAndLoad()
    }

    private fun setupBottomNav() {
        val soon = getString(R.string.tab_daily)
        binding.navDaily.setOnClickListener {
            Toast.makeText(this, "این بخش به‌زودی اضافه می‌شود", Toast.LENGTH_SHORT).show()
        }
        binding.navMap.setOnClickListener {
            Toast.makeText(this, "این بخش به‌زودی اضافه می‌شود", Toast.LENGTH_SHORT).show()
        }
        binding.navInfo.setOnClickListener {
            Toast.makeText(this, "این بخش به‌زودی اضافه می‌شود", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestLocationAndLoad() {
        val hasFine = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (hasFine || hasCoarse) {
            fetchDeviceLocationAndLoad()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun fetchDeviceLocationAndLoad() {
        try {
            val request = CurrentLocationRequest.Builder()
                .setPriority(Priority.PRIORITY_BALANCED_POWER_ACCURACY)
                .build()

            val cancellationTokenSource = CancellationTokenSource()
            fusedLocationClient.getCurrentLocation(request, cancellationTokenSource.token)
                .addOnSuccessListener { location ->
                    if (location != null) {
                        loadWeather(location.latitude, location.longitude, null)
                    } else {
                        Toast.makeText(this, getString(R.string.using_default_location), Toast.LENGTH_SHORT).show()
                        loadWeather(defaultLat, defaultLon, defaultCityName)
                    }
                }
                .addOnFailureListener {
                    loadWeather(defaultLat, defaultLon, defaultCityName)
                }
        } catch (e: SecurityException) {
            loadWeather(defaultLat, defaultLon, defaultCityName)
        }
    }

    private fun loadWeather(lat: Double, lon: Double, cityNameOverride: String?) {
        binding.swipeRefresh.isRefreshing = true
        binding.tvCityName.text = cityNameOverride ?: defaultCityName

        CoroutineScope(Dispatchers.Main).launch {
            try {
                val response = withContextIO { WeatherApi.service.getForecast(lat, lon) }
                bindWeather(response)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "خطا در دریافت اطلاعات آب‌وهوا", Toast.LENGTH_SHORT).show()
            } finally {
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private suspend fun <T> withContextIO(block: suspend () -> T): T =
        kotlinx.coroutines.withContext(Dispatchers.IO) { block() }

    private fun bindWeather(response: WeatherResponse) {
        val current = response.currentWeather
        val hourly = response.hourly

        if (current != null) {
            binding.tvTemp.text = PersianDate.toPersianDigits("${current.temperature.roundToInt()}°")
        }

        if (hourly != null && hourly.time.isNotEmpty()) {
            // find index matching current time (closest hour) for "now" stats
            val nowIndex = findClosestHourIndex(hourly, current?.time)

            if (nowIndex != -1) {
                binding.tvHumidity.text = PersianDate.toPersianDigits("${hourly.relativeHumidity2m[nowIndex]}%")
                binding.tvHumidityDetail.text = PersianDate.toPersianDigits("${hourly.relativeHumidity2m[nowIndex]}%")
                binding.tvFeelsLike.text = PersianDate.toPersianDigits("${hourly.apparentTemperature[nowIndex].roundToInt()}°")
                binding.tvPressure.text = PersianDate.toPersianDigits("${hourly.surfacePressure[nowIndex].roundToInt()}")
            }

            current?.let {
                binding.tvWind.text = PersianDate.toPersianDigits("${it.windSpeed.roundToInt()}")
            }

            val items = buildHourlyItems(hourly, nowIndex)
            binding.rvHourly.adapter = HourlyAdapter(items)
        }
    }

    private fun findClosestHourIndex(hourly: HourlyData, currentIsoTime: String?): Int {
        if (currentIsoTime == null) return 0
        // Open-Meteo returns ISO-like strings "YYYY-MM-DDTHH:MM"; hourly times also share the same format
        val currentHourPrefix = currentIsoTime.substring(0, 13) // up to hour
        val index = hourly.time.indexOfFirst { it.startsWith(currentHourPrefix) }
        return if (index != -1) index else 0
    }

    private fun buildHourlyItems(hourly: HourlyData, startIndex: Int): List<HourlyItem> {
        val items = mutableListOf<HourlyItem>()
        val safeStart = if (startIndex == -1) 0 else startIndex
        val end = minOf(safeStart + 7, hourly.time.size)
        for (i in safeStart until end) {
            val timeStr = hourly.time[i] // "YYYY-MM-DDTHH:MM"
            val hourPart = timeStr.substring(11, 13)
            val hourInt = hourPart.toIntOrNull() ?: 0
            val icon = WeatherApi.iconForCode(hourly.weatherCode.getOrElse(i) { 0 })
            val precip = hourly.precipitationProbability.getOrElse(i) { 0 }
            items.add(
                HourlyItem(
                    hourLabel = PersianDate.toPersianDigits(hourInt.toString()),
                    iconRes = icon,
                    precipPercent = precip
                )
            )
        }
        return items
    }
}
