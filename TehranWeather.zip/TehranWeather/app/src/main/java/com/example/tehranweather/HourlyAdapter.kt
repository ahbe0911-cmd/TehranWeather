package com.example.tehranweather

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.tehranweather.databinding.ItemHourlyBinding

data class HourlyItem(
    val hourLabel: String,
    val iconRes: Int,
    val precipPercent: Int
)

class HourlyAdapter(private val items: List<HourlyItem>) :
    RecyclerView.Adapter<HourlyAdapter.HourlyViewHolder>() {

    inner class HourlyViewHolder(val binding: ItemHourlyBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HourlyViewHolder {
        val binding = ItemHourlyBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return HourlyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HourlyViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvHour.text = item.hourLabel
        holder.binding.ivIcon.setImageResource(item.iconRes)
        holder.binding.tvPercent.text = PersianDate.toPersianDigits("${item.precipPercent}%")

        val maxHeightDp = 40
        val minHeightDp = 4
        val heightDp = (minHeightDp + (maxHeightDp - minHeightDp) * (item.precipPercent / 100f)).toInt()
        val density = holder.binding.barIndicator.resources.displayMetrics.density
        val params = holder.binding.barIndicator.layoutParams
        params.height = (heightDp * density).toInt()
        holder.binding.barIndicator.layoutParams = params
    }

    override fun getItemCount(): Int = items.size
}
