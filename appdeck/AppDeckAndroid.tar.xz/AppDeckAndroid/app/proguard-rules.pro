# AppDeck uses only AndroidX/Compose and platform APIs.
# Keep rules intentionally minimal; R8 handles Compose metadata automatically.
