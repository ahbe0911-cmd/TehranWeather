package ir.appdeck.launcher.util

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class PersianDateTest {
    @Test
    fun gregorianToJalali_currentReference() {
        assertEquals(JalaliDate(1405, 6, 8), PersianDate.fromGregorian(LocalDate.of(2026, 8, 30)))
    }

    @Test
    fun nowruzReference() {
        assertEquals(JalaliDate(1404, 1, 1), PersianDate.fromGregorian(LocalDate.of(2025, 3, 21)))
    }

    @Test
    fun reverseConversion() {
        assertEquals(GregorianDate(2026, 8, 30), PersianDate.toGregorian(1405, 6, 8))
    }
}
