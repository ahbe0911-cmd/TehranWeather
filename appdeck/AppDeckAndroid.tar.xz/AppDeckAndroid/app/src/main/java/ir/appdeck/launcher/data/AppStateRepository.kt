package ir.appdeck.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import ir.appdeck.launcher.model.AppSection
import ir.appdeck.launcher.model.SectionColor
import ir.appdeck.launcher.model.SectionIcon
import ir.appdeck.launcher.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "appdeck_state")

class AppStateRepository(private val context: Context) {
    private val sectionsKey = stringPreferencesKey("sections_json")
    private val themeKey = stringPreferencesKey("theme_mode")

    val sections: Flow<List<AppSection>> = context.dataStore.data.map { prefs ->
        decodeSections(prefs[sectionsKey].orEmpty())
    }

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        runCatching { ThemeMode.valueOf(prefs[themeKey] ?: ThemeMode.SYSTEM.name) }
            .getOrDefault(ThemeMode.SYSTEM)
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }

    suspend fun addSection(title: String, color: SectionColor, icon: SectionIcon) = updateSections { current ->
        current + AppSection(
            id = System.currentTimeMillis(),
            title = title.trim(),
            color = color,
            icon = icon
        )
    }

    suspend fun updateSection(id: Long, title: String, color: SectionColor, icon: SectionIcon) = updateSections { current ->
        current.map {
            if (it.id == id) it.copy(title = title.trim(), color = color, icon = icon) else it
        }
    }

    suspend fun deleteSection(id: Long) = updateSections { current ->
        current.filterNot { it.id == id }
    }

    suspend fun addPackages(sectionId: Long, packageNames: Collection<String>) = updateSections { current ->
        current.map { section ->
            if (section.id != sectionId) section
            else section.copy(packages = (section.packages + packageNames).distinct())
        }
    }

    suspend fun removePackage(sectionId: Long, packageName: String) = updateSections { current ->
        current.map { section ->
            if (section.id == sectionId) section.copy(packages = section.packages - packageName)
            else section
        }
    }

    suspend fun moveSection(id: Long, direction: Int) = updateSections { current ->
        val from = current.indexOfFirst { it.id == id }
        if (from < 0) return@updateSections current
        val to = (from + direction).coerceIn(0, current.lastIndex)
        if (to == from) return@updateSections current
        current.toMutableList().apply {
            val item = removeAt(from)
            add(to, item)
        }
    }

    suspend fun movePackage(sectionId: Long, packageName: String, direction: Int) = updateSections { current ->
        current.map { section ->
            if (section.id != sectionId) return@map section
            val from = section.packages.indexOf(packageName)
            if (from < 0) return@map section
            val to = (from + direction).coerceIn(0, section.packages.lastIndex)
            if (to == from) return@map section
            val reordered = section.packages.toMutableList().apply {
                val item = removeAt(from)
                add(to, item)
            }
            section.copy(packages = reordered)
        }
    }

    private suspend fun updateSections(block: (List<AppSection>) -> List<AppSection>) {
        context.dataStore.edit { prefs ->
            val current = decodeSections(prefs[sectionsKey].orEmpty())
            prefs[sectionsKey] = encodeSections(block(current))
        }
    }

    private fun encodeSections(items: List<AppSection>): String {
        val array = JSONArray()
        items.forEach { section ->
            array.put(JSONObject().apply {
                put("id", section.id)
                put("title", section.title)
                put("color", section.color.name)
                put("icon", section.icon.name)
                put("packages", JSONArray(section.packages))
            })
        }
        return array.toString()
    }

    private fun decodeSections(raw: String): List<AppSection> = runCatching {
        if (raw.isBlank()) return@runCatching emptyList()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val packagesArray = obj.optJSONArray("packages") ?: JSONArray()
                val packages = buildList {
                    for (j in 0 until packagesArray.length()) add(packagesArray.getString(j))
                }
                add(
                    AppSection(
                        id = obj.getLong("id"),
                        title = obj.getString("title"),
                        color = runCatching {
                            SectionColor.valueOf(obj.optString("color", SectionColor.BLUE.name))
                        }.getOrDefault(SectionColor.BLUE),
                        icon = runCatching {
                            SectionIcon.valueOf(obj.optString("icon", SectionIcon.WORK.name))
                        }.getOrDefault(SectionIcon.WORK),
                        packages = packages
                    )
                )
            }
        }
    }.getOrDefault(emptyList())
}
