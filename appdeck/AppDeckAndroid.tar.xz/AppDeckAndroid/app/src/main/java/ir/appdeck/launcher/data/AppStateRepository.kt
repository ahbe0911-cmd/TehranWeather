package ir.appdeck.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import ir.appdeck.launcher.model.AppSection
import ir.appdeck.launcher.model.CalendarNote
import ir.appdeck.launcher.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "appdeck_state")

class AppStateRepository(private val context: Context) {
    private val sectionsKey = stringPreferencesKey("sections_json")
    private val notesKey = stringPreferencesKey("notes_json")
    private val themeKey = stringPreferencesKey("theme_mode")

    val sections: Flow<List<AppSection>> = context.dataStore.data.map { prefs ->
        decodeSections(prefs[sectionsKey].orEmpty())
    }

    val notes: Flow<List<CalendarNote>> = context.dataStore.data.map { prefs ->
        decodeNotes(prefs[notesKey].orEmpty())
    }

    val themeMode: Flow<ThemeMode> = context.dataStore.data.map { prefs ->
        runCatching { ThemeMode.valueOf(prefs[themeKey] ?: ThemeMode.SYSTEM.name) }
            .getOrDefault(ThemeMode.SYSTEM)
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[themeKey] = mode.name }
    }

    suspend fun addSection(title: String) = updateSections { current ->
        current + AppSection(id = System.currentTimeMillis(), title = title.trim())
    }

    suspend fun renameSection(id: Long, title: String) = updateSections { current ->
        current.map { if (it.id == id) it.copy(title = title.trim()) else it }
    }

    suspend fun deleteSection(id: Long) = updateSections { current ->
        current.filterNot { it.id == id }
    }

    suspend fun addPackage(sectionId: Long, packageName: String) = updateSections { current ->
        current.map { section ->
            if (section.id != sectionId || packageName in section.packages) section
            else section.copy(packages = section.packages + packageName)
        }
    }

    suspend fun removePackage(sectionId: Long, packageName: String) = updateSections { current ->
        current.map { section ->
            if (section.id == sectionId) section.copy(packages = section.packages - packageName)
            else section
        }
    }

    suspend fun addNote(dateKey: String, text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return
        updateNotes { current ->
            current + CalendarNote(
                id = System.currentTimeMillis(),
                dateKey = dateKey,
                text = clean
            )
        }
    }

    suspend fun deleteNote(id: Long) = updateNotes { current ->
        current.filterNot { it.id == id }
    }

    private suspend fun updateSections(block: (List<AppSection>) -> List<AppSection>) {
        context.dataStore.edit { prefs ->
            val current = decodeSections(prefs[sectionsKey].orEmpty())
            prefs[sectionsKey] = encodeSections(block(current))
        }
    }

    private suspend fun updateNotes(block: (List<CalendarNote>) -> List<CalendarNote>) {
        context.dataStore.edit { prefs ->
            val current = decodeNotes(prefs[notesKey].orEmpty())
            prefs[notesKey] = encodeNotes(block(current))
        }
    }

    private fun encodeSections(items: List<AppSection>): String {
        val array = JSONArray()
        items.forEach { section ->
            array.put(JSONObject().apply {
                put("id", section.id)
                put("title", section.title)
                put("packages", JSONArray(section.packages))
            })
        }
        return array.toString()
    }

    private fun decodeSections(raw: String): List<AppSection> = runCatching {
        if (raw.isBlank()) return@runCatching emptyList()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val packagesArray = obj.optJSONArray("packages") ?: JSONArray()
                val packages = buildList {
                    for (j in 0 until packagesArray.length()) add(packagesArray.getString(j))
                }
                add(
                    AppSection(
                        id = obj.getLong("id"),
                        title = obj.getString("title"),
                        packages = packages
                    )
                )
            }
        }
    }.getOrDefault(emptyList())

    private fun encodeNotes(items: List<CalendarNote>): String {
        val array = JSONArray()
        items.forEach { note ->
            array.put(JSONObject().apply {
                put("id", note.id)
                put("dateKey", note.dateKey)
                put("text", note.text)
            })
        }
        return array.toString()
    }

    private fun decodeNotes(raw: String): List<CalendarNote> = runCatching {
        if (raw.isBlank()) return@runCatching emptyList()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                add(
                    CalendarNote(
                        id = obj.getLong("id"),
                        dateKey = obj.getString("dateKey"),
                        text = obj.getString("text")
                    )
                )
            }
        }
    }.getOrDefault(emptyList())
}
