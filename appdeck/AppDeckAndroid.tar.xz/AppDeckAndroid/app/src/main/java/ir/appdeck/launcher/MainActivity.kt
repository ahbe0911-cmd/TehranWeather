package ir.appdeck.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.appdeck.launcher.ui.AppDeckApp
import ir.appdeck.launcher.ui.theme.AppDeckTheme

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<MainViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val sections by viewModel.sections.collectAsStateWithLifecycle()
            val notes by viewModel.notes.collectAsStateWithLifecycle()
            val apps by viewModel.installedApps.collectAsStateWithLifecycle()
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

            AppDeckTheme(themeMode = themeMode) {
                AppDeckApp(
                    viewModel = viewModel,
                    sections = sections,
                    notes = notes,
                    installedApps = apps,
                    themeMode = themeMode
                )
            }
        }
    }
}
