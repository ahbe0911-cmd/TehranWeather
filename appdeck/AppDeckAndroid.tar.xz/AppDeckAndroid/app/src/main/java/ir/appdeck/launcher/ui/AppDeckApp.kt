@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.appdeck.launcher.ui

import android.content.Context
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import ir.appdeck.launcher.MainViewModel
import ir.appdeck.launcher.model.AppSection
import ir.appdeck.launcher.model.InstalledApp
import ir.appdeck.launcher.model.SectionColor
import ir.appdeck.launcher.model.SectionIcon
import ir.appdeck.launcher.model.ThemeMode

private enum class RootTab { DASHBOARD, SETTINGS }

@Composable
fun AppDeckApp(
    viewModel: MainViewModel,
    sections: List<AppSection>,
    installedApps: List<InstalledApp>,
    themeMode: ThemeMode
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        var tab by remember { mutableStateOf(RootTab.DASHBOARD) }
        var showAddSection by remember { mutableStateOf(false) }

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            bottomBar = {
                NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                    NavigationBarItem(
                        selected = tab == RootTab.DASHBOARD,
                        onClick = { tab = RootTab.DASHBOARD },
                        icon = { Icon(Icons.Default.Dashboard, null) },
                        label = { Text("داشبورد") }
                    )
                    NavigationBarItem(
                        selected = tab == RootTab.SETTINGS,
                        onClick = { tab = RootTab.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, null) },
                        label = { Text("تنظیمات") }
                    )
                }
            }
        ) { padding ->
            AnimatedContent(tab, label = "root-tab") { active ->
                when (active) {
                    RootTab.DASHBOARD -> DashboardScreen(
                        modifier = Modifier.padding(padding),
                        sections = sections,
                        installedApps = installedApps,
                        onAddSection = { showAddSection = true },
                        onUpdateSection = viewModel::updateSection,
                        onDeleteSection = viewModel::deleteSection,
                        onAddPackages = viewModel::addPackages,
                        onRemovePackage = viewModel::removePackage,
                        onMovePackage = viewModel::movePackage,
                        onRefreshApps = viewModel::refreshInstalledApps
                    )
                    RootTab.SETTINGS -> SettingsScreen(
                        modifier = Modifier.padding(padding),
                        sections = sections,
                        themeMode = themeMode,
                        onThemeChange = viewModel::setThemeMode,
                        onMoveSection = viewModel::moveSection
                    )
                }
            }
        }

        if (showAddSection) {
            SectionEditorDialog(
                title = "ساخت بخش جدید",
                confirmText = "ایجاد بخش",
                initialSection = null,
                onDismiss = { showAddSection = false },
                onConfirm = { name, color, icon ->
                    viewModel.addSection(name, color, icon)
                    showAddSection = false
                }
            )
        }
    }
}

@Composable
private fun DashboardScreen(
    modifier: Modifier,
    sections: List<AppSection>,
    installedApps: List<InstalledApp>,
    onAddSection: () -> Unit,
    onUpdateSection: (Long, String, SectionColor, SectionIcon) -> Unit,
    onDeleteSection: (Long) -> Unit,
    onAddPackages: (Long, Collection<String>) -> Unit,
    onRemovePackage: (Long, String) -> Unit,
    onMovePackage: (Long, String, Int) -> Unit,
    onRefreshApps: () -> Unit
) {
    val context = LocalContext.current
    var pickerSection by remember { mutableStateOf<AppSection?>(null) }
    var editSection by remember { mutableStateOf<AppSection?>(null) }
    var manageSection by remember { mutableStateOf<AppSection?>(null) }
    var searchOpen by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val appMap = remember(installedApps) { installedApps.associateBy { it.packageName } }
    val visibleSections = remember(sections, query) {
        if (query.isBlank()) sections else sections.mapNotNull { section ->
            val titleMatches = section.title.contains(query, ignoreCase = true)
            val matchingPackages = section.packages.filter { pkg ->
                val app = appMap[pkg]
                app?.label?.contains(query, ignoreCase = true) == true || pkg.contains(query, ignoreCase = true)
            }
            when {
                titleMatches -> section
                matchingPackages.isNotEmpty() -> section.copy(packages = matchingPackages)
                else -> null
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            DashboardTopBar(
                searchOpen = searchOpen,
                query = query,
                onQueryChange = { query = it },
                onSearchToggle = {
                    searchOpen = !searchOpen
                    if (!searchOpen) query = ""
                },
                onAddSection = onAddSection
            )
        }

        if (sections.isEmpty()) {
            item { EmptyDashboardCard(onAddSection) }
        } else if (visibleSections.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "برنامه‌ای با این عبارت پیدا نشد.",
                        modifier = Modifier.padding(22.dp),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(visibleSections, key = { it.id }) { section ->
                SectionCard(
                    section = section,
                    appMap = appMap,
                    context = context,
                    onAddClick = { pickerSection = section },
                    onEditClick = { editSection = section },
                    onManageClick = { manageSection = section },
                    onDeleteClick = { onDeleteSection(section.id) },
                    onRemovePackage = { onRemovePackage(section.id, it) }
                )
            }
        }

        item {
            TextButton(onClick = onRefreshApps, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("تازه‌سازی فهرست برنامه‌های نصب‌شده")
            }
        }
    }

    pickerSection?.let { section ->
        AppPickerDialog(
            section = section,
            apps = installedApps,
            onDismiss = { pickerSection = null },
            onConfirm = { packages ->
                onAddPackages(section.id, packages)
                pickerSection = null
            }
        )
    }

    editSection?.let { section ->
        SectionEditorDialog(
            title = "ویرایش بخش",
            confirmText = "ذخیره تغییرات",
            initialSection = section,
            onDismiss = { editSection = null },
            onConfirm = { name, color, icon ->
                onUpdateSection(section.id, name, color, icon)
                editSection = null
            }
        )
    }

    manageSection?.let { section ->
        ManageAppsDialog(
            section = section,
            appMap = appMap,
            onDismiss = { manageSection = null },
            onRemove = { onRemovePackage(section.id, it) },
            onMove = { pkg, direction -> onMovePackage(section.id, pkg, direction) }
        )
    }
}

@Composable
private fun DashboardTopBar(
    searchOpen: Boolean,
    query: String,
    onQueryChange: (String) -> Unit,
    onSearchToggle: () -> Unit,
    onAddSection: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onSearchToggle) {
                Icon(Icons.Default.Search, contentDescription = "جست‌وجو")
            }
            Text(
                "داشبورد من",
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                fontSize = 21.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary
            ) {
                IconButton(onClick = onAddSection, modifier = Modifier.size(42.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "ساخت بخش", tint = Color.White)
                }
            }
        }

        if (searchOpen) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null) },
                placeholder = { Text("جست‌وجوی برنامه یا بخش") },
                shape = RoundedCornerShape(18.dp)
            )
        }
    }
}

@Composable
private fun EmptyDashboardCard(onAddSection: () -> Unit) {
    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)) {
                Icon(
                    Icons.Default.Apps,
                    null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(17.dp).size(32.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Text("اولین بخش را بساز", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Spacer(Modifier.height(7.dp))
            Text(
                "مثلاً کار، شبکه‌های اجتماعی، ابزارها یا بانک‌ها. بعد برنامه‌های دلخواهت را داخل همان کارت قرار بده.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 24.sp
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAddSection, shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("ساخت بخش")
            }
        }
    }
}

@Composable
private fun SectionCard(
    section: AppSection,
    appMap: Map<String, InstalledApp>,
    context: Context,
    onAddClick: () -> Unit,
    onEditClick: () -> Unit,
    onManageClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onRemovePackage: (String) -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val accent = section.color.toColor()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.5.dp, accent.copy(alpha = 0.75f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(11.dp),
                    color = accent.copy(alpha = 0.12f)
                ) {
                    Icon(
                        section.icon.toImageVector(),
                        null,
                        tint = accent,
                        modifier = Modifier.padding(8.dp).size(23.dp)
                    )
                }
                Spacer(Modifier.width(9.dp))
                Text(
                    section.title,
                    modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp
                )
                IconButton(onClick = onEditClick, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "ویرایش بخش")
                }
                Box {
                    IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(40.dp)) {
                        Icon(Icons.Default.MoreVert, contentDescription = "منوی بخش")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("افزودن برنامه") },
                            leadingIcon = { Icon(Icons.Default.Add, null) },
                            onClick = { menuOpen = false; onAddClick() }
                        )
                        DropdownMenuItem(
                            text = { Text("مرتب‌سازی برنامه‌ها") },
                            leadingIcon = { Icon(Icons.Default.Apps, null) },
                            onClick = { menuOpen = false; onManageClick() }
                        )
                        DropdownMenuItem(
                            text = { Text("حذف بخش") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                            onClick = { menuOpen = false; onDeleteClick() }
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            if (section.packages.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.42f),
                    modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onAddClick)
                ) {
                    Text(
                        "برای افزودن برنامه اینجا را لمس کن",
                        modifier = Modifier.padding(15.dp),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            } else {
                val rows = (section.packages.size + 4) / 5
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    userScrollEnabled = false,
                    modifier = Modifier.height((rows * 88).dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    gridItems(section.packages, key = { it }) { pkg ->
                        val app = appMap[pkg]
                        AppTile(
                            packageName = pkg,
                            label = app?.label ?: "حذف‌شده",
                            context = context,
                            onRemove = { onRemovePackage(pkg) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppTile(
    packageName: String,
    label: String,
    context: Context,
    onRemove: () -> Unit
) {
    val icon = remember(packageName) {
        runCatching { context.packageManager.getApplicationIcon(packageName) }.getOrNull()
    }
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(15.dp))
            .combinedClickable(
                onClick = { launchPackage(context, packageName) },
                onLongClick = onRemove
            )
            .padding(horizontal = 2.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.22f))
        ) {
            AppIcon(icon = icon, label = label, modifier = Modifier.padding(7.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(
            label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 10.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun AppIcon(icon: Drawable?, label: String, modifier: Modifier = Modifier) {
    if (icon == null) {
        Icon(
            Icons.Default.Apps,
            null,
            modifier = modifier.size(34.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
    } else {
        Image(
            bitmap = remember(icon) { icon.toBitmap(96, 96).asImageBitmap() },
            contentDescription = label,
            modifier = modifier.size(40.dp).clip(RoundedCornerShape(10.dp)),
            contentScale = ContentScale.Fit
        )
    }
}

private fun launchPackage(context: Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) {
        Toast.makeText(context, "این برنامه قابل اجرا نیست.", Toast.LENGTH_SHORT).show()
        return
    }
    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

@Composable
private fun SectionEditorDialog(
    title: String,
    confirmText: String,
    initialSection: AppSection?,
    onDismiss: () -> Unit,
    onConfirm: (String, SectionColor, SectionIcon) -> Unit
) {
    var name by remember(initialSection?.id) { mutableStateOf(initialSection?.title.orEmpty()) }
    var selectedColor by remember(initialSection?.id) {
        mutableStateOf(initialSection?.color ?: SectionColor.BLUE)
    }
    var selectedIcon by remember(initialSection?.id) {
        mutableStateOf(initialSection?.icon ?: SectionIcon.WORK)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(15.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("نام بخش") },
                    placeholder = { Text("مثلاً کار") },
                    shape = RoundedCornerShape(15.dp)
                )

                Text("رنگ بخش", fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    SectionColor.entries.forEach { color ->
                        val actual = color.toColor()
                        Surface(
                            modifier = Modifier.size(42.dp).combinedClickable(onClick = { selectedColor = color }),
                            shape = CircleShape,
                            color = actual,
                            border = if (selectedColor == color) BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else null
                        ) {
                            if (selectedColor == color) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Check, null, tint = Color.White)
                                }
                            }
                        }
                    }
                }

                Text("آیکون بخش", fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(SectionIcon.entries) { icon ->
                        val selected = selectedIcon == icon
                        Surface(
                            modifier = Modifier.size(46.dp).combinedClickable(onClick = { selectedIcon = icon }),
                            shape = RoundedCornerShape(13.dp),
                            color = if (selected) selectedColor.toColor().copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = if (selected) BorderStroke(1.5.dp, selectedColor.toColor()) else null
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(icon.toImageVector(), null, tint = if (selected) selectedColor.toColor() else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onConfirm(name.trim(), selectedColor, selectedIcon) },
                enabled = name.isNotBlank(),
                shape = RoundedCornerShape(13.dp)
            ) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun AppPickerDialog(
    section: AppSection,
    apps: List<InstalledApp>,
    onDismiss: () -> Unit,
    onConfirm: (Set<String>) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selected by remember(section.id) { mutableStateOf(emptySet<String>()) }
    val context = LocalContext.current
    val filtered = remember(apps, query, section.packages) {
        apps.filter {
            it.packageName !in section.packages &&
                (query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن برنامه‌ها", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                Text(
                    "برنامه‌های موردنظر برای «${section.title}» را انتخاب کن.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    placeholder = { Text("جست‌وجوی برنامه") },
                    shape = RoundedCornerShape(15.dp)
                )
                Spacer(Modifier.height(8.dp))
                LazyColumn(modifier = Modifier.height(420.dp)) {
                    items(filtered, key = { it.packageName }) { app ->
                        val checked = app.packageName in selected
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(13.dp))
                                .combinedClickable(onClick = {
                                    selected = if (checked) selected - app.packageName else selected + app.packageName
                                })
                                .padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = checked,
                                onCheckedChange = {
                                    selected = if (checked) selected - app.packageName else selected + app.packageName
                                }
                            )
                            val icon = remember(app.packageName) {
                                runCatching { context.packageManager.getApplicationIcon(app.packageName) }.getOrNull()
                            }
                            AppIcon(icon, app.label)
                            Spacer(Modifier.width(10.dp))
                            Text(app.label, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selected) },
                enabled = selected.isNotEmpty(),
                shape = RoundedCornerShape(13.dp)
            ) {
                Text(if (selected.isEmpty()) "افزودن به بخش" else "افزودن ${selected.size} برنامه")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun ManageAppsDialog(
    section: AppSection,
    appMap: Map<String, InstalledApp>,
    onDismiss: () -> Unit,
    onRemove: (String) -> Unit,
    onMove: (String, Int) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مرتب‌سازی برنامه‌ها", fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                Text(
                    "ترتیب نمایش برنامه‌های «${section.title}» را تغییر بده یا برنامه‌ای را حذف کن.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(modifier = Modifier.height(390.dp)) {
                    items(section.packages, key = { it }) { pkg ->
                        val app = appMap[pkg]
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                app?.label ?: pkg,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            IconButton(onClick = { onMove(pkg, -1) }) {
                                Icon(Icons.Default.ArrowUpward, "بالاتر")
                            }
                            IconButton(onClick = { onMove(pkg, 1) }) {
                                Icon(Icons.Default.ArrowDownward, "پایین‌تر")
                            }
                            IconButton(onClick = { onRemove(pkg) }) {
                                Icon(Icons.Default.Delete, "حذف")
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    }
                }
            }
        },
        confirmButton = { Button(onClick = onDismiss) { Text("تمام") } }
    )
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    sections: List<AppSection>,
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit,
    onMoveSection: (Long, Int) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("تنظیمات", fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(
                "ظاهر داشبورد و ترتیب بخش‌ها",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        item {
            Card(shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)) {
                            Icon(Icons.Default.Palette, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(10.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("حالت نمایش", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    }
                    ThemeChoice("طبق تنظیمات گوشی", ThemeMode.SYSTEM, themeMode, onThemeChange, Icons.Default.Settings)
                    ThemeChoice("روشن", ThemeMode.LIGHT, themeMode, onThemeChange, Icons.Default.LightMode)
                    ThemeChoice("تیره", ThemeMode.DARK, themeMode, onThemeChange, Icons.Default.DarkMode)
                }
            }
        }

        item {
            Text("مرتب‌سازی بخش‌ها", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }

        if (sections.isEmpty()) {
            item {
                Text(
                    "هنوز بخشی ساخته نشده است.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items(sections, key = { it.id }) { section ->
                Card(shape = RoundedCornerShape(17.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val accent = section.color.toColor()
                        Surface(shape = RoundedCornerShape(10.dp), color = accent.copy(alpha = 0.12f)) {
                            Icon(section.icon.toImageVector(), null, tint = accent, modifier = Modifier.padding(8.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(section.title, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        IconButton(onClick = { onMoveSection(section.id, -1) }) {
                            Icon(Icons.Default.ArrowUpward, "بالاتر")
                        }
                        IconButton(onClick = { onMoveSection(section.id, 1) }) {
                            Icon(Icons.Default.ArrowDownward, "پایین‌تر")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemeChoice(
    title: String,
    mode: ThemeMode,
    current: ThemeMode,
    onChange: (ThemeMode) -> Unit,
    icon: ImageVector
) {
    OutlinedButton(
        onClick = { onChange(mode) },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(
            if (current == mode) 1.5.dp else 1.dp,
            if (current == mode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
        )
    ) {
        Icon(icon, null)
        Spacer(Modifier.width(8.dp))
        Text(title, modifier = Modifier.weight(1f), textAlign = TextAlign.Start)
        if (current == mode) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary)
    }
}

private fun SectionColor.toColor(): Color = when (this) {
    SectionColor.BLUE -> Color(0xFF1769FF)
    SectionColor.PURPLE -> Color(0xFF7B3FE4)
    SectionColor.GREEN -> Color(0xFF12B76A)
    SectionColor.ORANGE -> Color(0xFFFF7A00)
    SectionColor.PINK -> Color(0xFFEC407A)
}

private fun SectionIcon.toImageVector(): ImageVector = when (this) {
    SectionIcon.WORK -> Icons.Default.Work
    SectionIcon.SOCIAL -> Icons.Default.Groups
    SectionIcon.TOOLS -> Icons.Default.Build
    SectionIcon.BANK -> Icons.Default.AccountBalance
    SectionIcon.STAR -> Icons.Default.Star
    SectionIcon.SCHOOL -> Icons.Default.School
    SectionIcon.SHOPPING -> Icons.Default.ShoppingBag
    SectionIcon.FAVORITE -> Icons.Default.Favorite
}
