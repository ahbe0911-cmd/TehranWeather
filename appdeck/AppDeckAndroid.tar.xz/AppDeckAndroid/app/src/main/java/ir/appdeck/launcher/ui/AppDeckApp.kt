@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package ir.appdeck.launcher.ui

import android.content.Context
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.SystemUpdateAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import ir.appdeck.launcher.MainViewModel
import ir.appdeck.launcher.model.AppSection
import ir.appdeck.launcher.model.CalendarNote
import ir.appdeck.launcher.model.InstalledApp
import ir.appdeck.launcher.model.ThemeMode
import ir.appdeck.launcher.ui.theme.Coral
import ir.appdeck.launcher.ui.theme.Green
import ir.appdeck.launcher.ui.theme.Ink
import ir.appdeck.launcher.ui.theme.Purple
import ir.appdeck.launcher.ui.theme.Yellow
import ir.appdeck.launcher.util.JalaliDate
import ir.appdeck.launcher.util.PersianDate
import ir.appdeck.launcher.util.fullPersianText
import ir.appdeck.launcher.util.persianMonths
import ir.appdeck.launcher.util.toPersianDigits
import java.time.LocalDate

private enum class RootTab { HOME, CALENDAR, SETTINGS }

@Composable
fun AppDeckApp(
    viewModel: MainViewModel,
    sections: List<AppSection>,
    notes: List<CalendarNote>,
    installedApps: List<InstalledApp>,
    themeMode: ThemeMode
) {
    var tab by remember { mutableStateOf(RootTab.HOME) }
    var showAddSection by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(modifier = Modifier.navigationBarsPadding()) {
                NavigationBarItem(
                    selected = tab == RootTab.HOME,
                    onClick = { tab = RootTab.HOME },
                    icon = { Icon(Icons.Default.Home, null) },
                    label = { Text("خانه") }
                )
                NavigationBarItem(
                    selected = tab == RootTab.CALENDAR,
                    onClick = { tab = RootTab.CALENDAR },
                    icon = { Icon(Icons.Default.CalendarMonth, null) },
                    label = { Text("تقویم") }
                )
                NavigationBarItem(
                    selected = tab == RootTab.SETTINGS,
                    onClick = { tab = RootTab.SETTINGS },
                    icon = { Icon(Icons.Default.Settings, null) },
                    label = { Text("تنظیمات") }
                )
            }
        },
        floatingActionButton = {
            if (tab == RootTab.HOME) {
                FloatingActionButton(onClick = { showAddSection = true }) {
                    Icon(Icons.Default.Add, contentDescription = "افزودن بخش")
                }
            }
        }
    ) { padding ->
        AnimatedContent(tab, label = "root-tab") { active ->
            when (active) {
                RootTab.HOME -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    sections = sections,
                    installedApps = installedApps,
                    onRename = viewModel::renameSection,
                    onDelete = viewModel::deleteSection,
                    onAddPackage = viewModel::addPackage,
                    onRemovePackage = viewModel::removePackage,
                    onRefreshApps = viewModel::refreshInstalledApps
                )
                RootTab.CALENDAR -> CalendarScreen(
                    modifier = Modifier.padding(padding),
                    notes = notes,
                    onAddNote = viewModel::addNote,
                    onDeleteNote = viewModel::deleteNote
                )
                RootTab.SETTINGS -> SettingsScreen(
                    modifier = Modifier.padding(padding),
                    themeMode = themeMode,
                    onThemeChange = viewModel::setThemeMode
                )
            }
        }
    }

    if (showAddSection) {
        TextInputDialog(
            title = "بخش جدید",
            hint = "مثلاً کار، شبکه‌های اجتماعی، ابزارها",
            confirmText = "ساخت بخش",
            onDismiss = { showAddSection = false },
            onConfirm = {
                if (it.isNotBlank()) viewModel.addSection(it)
                showAddSection = false
            }
        )
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    sections: List<AppSection>,
    installedApps: List<InstalledApp>,
    onRename: (Long, String) -> Unit,
    onDelete: (Long) -> Unit,
    onAddPackage: (Long, String) -> Unit,
    onRemovePackage: (Long, String) -> Unit,
    onRefreshApps: () -> Unit
) {
    val context = LocalContext.current
    val today = remember { PersianDate.today() }
    var pickerSection by remember { mutableStateOf<AppSection?>(null) }
    var renameSection by remember { mutableStateOf<AppSection?>(null) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            HeaderCard(today = today, sectionCount = sections.size)
        }

        if (sections.isEmpty()) {
            item {
                EmptyDashboardCard()
            }
        } else {
            items(sections, key = { it.id }) { section ->
                SectionCard(
                    section = section,
                    installedApps = installedApps,
                    context = context,
                    onAddClick = { pickerSection = section },
                    onRenameClick = { renameSection = section },
                    onDeleteClick = { onDelete(section.id) },
                    onRemovePackage = { onRemovePackage(section.id, it) }
                )
            }
        }

        item {
            TextButton(onClick = onRefreshApps, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("تازه‌سازی فهرست برنامه‌ها")
            }
        }
    }

    pickerSection?.let { section ->
        AppPickerDialog(
            section = section,
            apps = installedApps,
            onDismiss = { pickerSection = null },
            onPick = { pkg -> onAddPackage(section.id, pkg) }
        )
    }

    renameSection?.let { section ->
        TextInputDialog(
            title = "تغییر نام بخش",
            initial = section.title,
            hint = "نام جدید",
            confirmText = "ذخیره",
            onDismiss = { renameSection = null },
            onConfirm = {
                if (it.isNotBlank()) onRename(section.id, it)
                renameSection = null
            }
        )
    }
}

@Composable
private fun HeaderCard(today: JalaliDate, sectionCount: Int) {
    Card(
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = Ink),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Dot(Coral)
                    Dot(Yellow)
                    Dot(Green)
                }
                Spacer(Modifier.weight(1f))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Purple.copy(alpha = 0.22f)
                ) {
                    Text(
                        "APPDECK",
                        color = androidx.compose.ui.graphics.Color.White,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(Modifier.height(26.dp))
            Text(
                text = "برنامه‌های مهمت، مرتب و یک لمس فاصله",
                color = androidx.compose.ui.graphics.Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                lineHeight = 32.sp
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = today.fullPersianText(),
                color = androidx.compose.ui.graphics.Color(0xFFD9E5EA),
                fontSize = 16.sp
            )
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniStat("بخش‌ها", sectionCount.toString().toPersianDigits())
                MiniStat("دسترسی", "سریع")
                MiniStat("تقویم", "شمسی")
            }
        }
    }
}

@Composable
private fun Dot(color: androidx.compose.ui.graphics.Color) {
    Box(Modifier.size(12.dp).clip(CircleShape).background(color))
}

@Composable
private fun MiniStat(label: String, value: String) {
    Surface(
        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.08f),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) {
            Text(value, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
            Text(label, color = androidx.compose.ui.graphics.Color(0xFF9FB3BD), fontSize = 11.sp)
        }
    }
}

@Composable
private fun EmptyDashboardCard() {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(shape = CircleShape, color = Purple.copy(alpha = 0.12f)) {
                Icon(
                    Icons.Default.Apps,
                    null,
                    tint = Purple,
                    modifier = Modifier.padding(16.dp).size(30.dp)
                )
            }
            Spacer(Modifier.height(14.dp))
            Text("اولین بخش خودت را بساز", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "مثلاً «کار»، «اینترنت»، «بانک‌ها» یا هر اسم دلخواه. بعد برنامه‌ها را داخل همان باکس اضافه کن.",
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 24.sp
            )
        }
    }
}

@Composable
private fun SectionCard(
    section: AppSection,
    installedApps: List<InstalledApp>,
    context: Context,
    onAddClick: () -> Unit,
    onRenameClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onRemovePackage: (String) -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    val appMap = remember(installedApps) { installedApps.associateBy { it.packageName } }

    Card(
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = Purple.copy(alpha = 0.12f)) {
                    Icon(Icons.Default.Smartphone, null, tint = Purple, modifier = Modifier.padding(10.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(section.title, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text(
                        "${section.packages.size.toPersianDigits()} برنامه",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp
                    )
                }
                IconButton(onClick = onAddClick) {
                    Icon(Icons.Default.Add, contentDescription = "افزودن برنامه")
                }
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "منو")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("تغییر نام") },
                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                            onClick = { menuOpen = false; onRenameClick() }
                        )
                        DropdownMenuItem(
                            text = { Text("حذف بخش") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                            onClick = { menuOpen = false; onDeleteClick() }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            if (section.packages.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        "هنوز برنامه‌ای اضافه نشده — روی + بزن.",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                val rows = (section.packages.size + 3) / 4
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    userScrollEnabled = false,
                    modifier = Modifier.height((rows * 96).dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    gridItems(section.packages, key = { it }) { pkg ->
                        val app = appMap[pkg]
                        AppTile(
                            packageName = pkg,
                            label = app?.label ?: "حذف‌شده",
                            context = context,
                            onRemove = { onRemovePackage(pkg) }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppTile(
    packageName: String,
    label: String,
    context: Context,
    onRemove: () -> Unit
) {
    val icon = remember(packageName) { runCatching { context.packageManager.getApplicationIcon(packageName) }.getOrNull() }
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = { launchPackage(context, packageName) },
                onLongClick = onRemove
            )
            .padding(horizontal = 4.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(icon = icon, label = label)
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            fontSize = 11.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun AppIcon(icon: Drawable?, label: String) {
    if (icon == null) {
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Icon(Icons.Default.Apps, null, modifier = Modifier.padding(12.dp).size(26.dp))
        }
    } else {
        androidx.compose.foundation.Image(
            bitmap = remember(icon) { icon.toBitmap(96, 96).asImageBitmap() },
            contentDescription = label,
            modifier = Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)),
            contentScale = ContentScale.Fit
        )
    }
}

private fun launchPackage(context: Context, packageName: String) {
    val intent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (intent == null) {
        Toast.makeText(context, "این برنامه قابل اجرا نیست.", Toast.LENGTH_SHORT).show()
        return
    }
    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}

@Composable
private fun AppPickerDialog(
    section: AppSection,
    apps: List<InstalledApp>,
    onDismiss: () -> Unit,
    onPick: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query, section.packages) {
        apps.filter {
            it.packageName !in section.packages &&
                (query.isBlank() || it.label.contains(query, true) || it.packageName.contains(query, true))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن برنامه به «${section.title}»") },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    placeholder = { Text("جست‌وجوی برنامه") }
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(modifier = Modifier.height(420.dp)) {
                    items(filtered, key = { it.packageName }) { app ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .combinedClickable(onClick = { onPick(app.packageName) })
                                .padding(vertical = 9.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val context = LocalContext.current
                            val icon = remember(app.packageName) {
                                runCatching { context.packageManager.getApplicationIcon(app.packageName) }.getOrNull()
                            }
                            AppIcon(icon, app.label)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(app.label, fontWeight = FontWeight.Bold)
                                Text(
                                    app.packageName,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Default.Add, null, tint = Purple)
                        }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("تمام") } }
    )
}

@Composable
private fun CalendarScreen(
    modifier: Modifier,
    notes: List<CalendarNote>,
    onAddNote: (String, String) -> Unit,
    onDeleteNote: (Long) -> Unit
) {
    val today = remember { PersianDate.today() }
    var year by remember { mutableIntStateOf(today.year) }
    var month by remember { mutableIntStateOf(today.month) }
    var selectedDay by remember { mutableIntStateOf(today.day) }
    var showAddNote by remember { mutableStateOf(false) }

    val selected = JalaliDate(year, month, selectedDay.coerceAtMost(PersianDate.daysInMonth(year, month)))
    val selectedNotes = notes.filter { it.dateKey == selected.key }

    LazyColumn(
        modifier = modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Ink)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("تقویم شمسی", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                        Text(
                            "برای هر روز یادداشت و برنامه ثبت کن",
                            color = androidx.compose.ui.graphics.Color(0xFFB6C7CF),
                            fontSize = 13.sp
                        )
                    }
                    Surface(shape = CircleShape, color = Purple.copy(alpha = 0.3f)) {
                        Icon(Icons.Default.CalendarMonth, null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.padding(13.dp))
                    }
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(26.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = {
                            month--
                            if (month < 1) { month = 12; year-- }
                            selectedDay = 1
                        }) { Icon(Icons.Default.ChevronRight, "ماه قبل") }

                        Text(
                            "${persianMonths[month - 1]} ${year.toPersianDigits()}",
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )

                        IconButton(onClick = {
                            month++
                            if (month > 12) { month = 1; year++ }
                            selectedDay = 1
                        }) { Icon(Icons.Default.ChevronLeft, "ماه بعد") }
                    }

                    Spacer(Modifier.height(8.dp))
                    CalendarGrid(
                        year = year,
                        month = month,
                        selectedDay = selectedDay,
                        today = today,
                        noteDateKeys = notes.asSequence().map { it.dateKey }.toSet(),
                        onDaySelected = { selectedDay = it }
                    )
                }
            }
        }

        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("${selected.day.toPersianDigits()} ${persianMonths[selected.month - 1]}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("یادداشت‌های این روز", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
                Button(onClick = { showAddNote = true }) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("یادداشت")
                }
            }
        }

        if (selectedNotes.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Text(
                        "برای این تاریخ هنوز چیزی ثبت نشده.",
                        modifier = Modifier.padding(18.dp),
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            items(selectedNotes, key = { it.id }) { note ->
                Card(shape = RoundedCornerShape(18.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 14.dp, end = 6.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(Purple))
                        Spacer(Modifier.width(10.dp))
                        Text(note.text, modifier = Modifier.weight(1f), lineHeight = 23.sp)
                        IconButton(onClick = { onDeleteNote(note.id) }) {
                            Icon(Icons.Default.Close, "حذف")
                        }
                    }
                }
            }
        }
    }

    if (showAddNote) {
        TextInputDialog(
            title = "یادداشت ${selected.day.toPersianDigits()} ${persianMonths[selected.month - 1]}",
            hint = "کار، قرار، یادآوری یا هر متن دلخواه",
            confirmText = "ذخیره",
            onDismiss = { showAddNote = false },
            onConfirm = {
                onAddNote(selected.key, it)
                showAddNote = false
            }
        )
    }
}

@Composable
private fun CalendarGrid(
    year: Int,
    month: Int,
    selectedDay: Int,
    today: JalaliDate,
    noteDateKeys: Set<String>,
    onDaySelected: (Int) -> Unit
) {
    val weekNames = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")
    val firstGregorian = remember(year, month) { PersianDate.toGregorian(year, month, 1) }
    val firstDow = remember(firstGregorian) {
        LocalDate.of(firstGregorian.year, firstGregorian.month, firstGregorian.day).dayOfWeek.value
    }
    val offset = (firstDow + 1) % 7
    val days = PersianDate.daysInMonth(year, month)
    val cells = remember(year, month) { List(offset) { 0 } + (1..days).toList() }

    Row(Modifier.fillMaxWidth()) {
        weekNames.forEachIndexed { index, name ->
            Text(
                name,
                modifier = Modifier.weight(1f).padding(vertical = 7.dp),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
                color = if (index == 6) Coral else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    val rows = (cells.size + 6) / 7
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(rows) { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                repeat(7) { col ->
                    val index = row * 7 + col
                    val day = cells.getOrNull(index) ?: 0
                    val isSelected = day == selectedDay
                    val isToday = day == today.day && month == today.month && year == today.year
                    val hasNote = day > 0 && JalaliDate(year, month, day).key in noteDateKeys

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                when {
                                    isSelected -> Purple
                                    isToday -> Purple.copy(alpha = 0.12f)
                                    else -> androidx.compose.ui.graphics.Color.Transparent
                                }
                            )
                            .combinedClickable(enabled = day > 0, onClick = { if (day > 0) onDaySelected(day) }),
                        contentAlignment = Alignment.Center
                    ) {
                        if (day > 0) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    day.toPersianDigits(),
                                    color = if (isSelected) androidx.compose.ui.graphics.Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = if (isToday || isSelected) FontWeight.ExtraBold else FontWeight.Medium
                                )
                                if (hasNote) {
                                    Spacer(Modifier.height(2.dp))
                                    Box(
                                        Modifier.size(4.dp).clip(CircleShape).background(
                                            if (isSelected) androidx.compose.ui.graphics.Color.White else Green
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier,
    themeMode: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("تنظیمات", fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
            Text("ظاهر و رفتار AppDeck", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        item {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("پوسته", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Spacer(Modifier.height(10.dp))
                    ThemeChoice("خودکار با سیستم", Icons.Default.SystemUpdateAlt, ThemeMode.SYSTEM, themeMode, onThemeChange)
                    ThemeChoice("روشن", Icons.Default.LightMode, ThemeMode.LIGHT, themeMode, onThemeChange)
                    ThemeChoice("تیره", Icons.Default.DarkMode, ThemeMode.DARK, themeMode, onThemeChange)
                }
            }
        }

        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Ink)) {
                Column(Modifier.padding(18.dp)) {
                    Text("برای سرعت طراحی شده", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "فهرست برنامه‌ها فقط از Launcher اندروید خوانده می‌شود و AppDeck مجوز سنگین QUERY_ALL_PACKAGES نمی‌خواهد. اطلاعات بخش‌ها و یادداشت‌های تقویم هم به‌صورت محلی ذخیره می‌شوند.",
                        color = androidx.compose.ui.graphics.Color(0xFFC7D3D9),
                        lineHeight = 23.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemeChoice(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    mode: ThemeMode,
    selected: ThemeMode,
    onThemeChange: (ThemeMode) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).combinedClickable(onClick = { onThemeChange(mode) }),
        color = if (selected == mode) Purple.copy(alpha = 0.12f) else androidx.compose.ui.graphics.Color.Transparent
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (selected == mode) Purple else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(12.dp))
            Text(title, modifier = Modifier.weight(1f), fontWeight = if (selected == mode) FontWeight.Bold else FontWeight.Medium)
            if (selected == mode) Box(Modifier.size(10.dp).clip(CircleShape).background(Purple))
        }
    }
}

@Composable
private fun TextInputDialog(
    title: String,
    hint: String,
    confirmText: String,
    initial: String = "",
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var value by remember(initial) { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(hint) },
                minLines = 1,
                maxLines = 4
            )
        },
        confirmButton = {
            Button(onClick = { onConfirm(value) }, enabled = value.isNotBlank()) {
                Text(confirmText)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
