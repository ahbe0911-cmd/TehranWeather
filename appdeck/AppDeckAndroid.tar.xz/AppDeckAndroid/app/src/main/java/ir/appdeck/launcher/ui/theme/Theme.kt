package ir.appdeck.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import ir.appdeck.launcher.model.ThemeMode

val Ink = Color(0xFF071621)
val InkSoft = Color(0xFF102632)
val Cream = Color(0xFFF8F7F3)
val Purple = Color(0xFF6F3FF5)
val PurpleSoft = Color(0xFFEDE7FF)
val Green = Color(0xFF38D27A)
val Yellow = Color(0xFFFFC83D)
val Coral = Color(0xFFFF6B63)

private val LightColors = lightColorScheme(
    primary = Purple,
    onPrimary = Color.White,
    secondary = Green,
    tertiary = Yellow,
    background = Cream,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF0EEE8),
    onSurfaceVariant = Color(0xFF4B565D),
    outline = Color(0xFFD8D3CB)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9C7CFF),
    onPrimary = Color(0xFF201050),
    secondary = Green,
    tertiary = Yellow,
    background = Color(0xFF051019),
    onBackground = Color(0xFFF5F6F8),
    surface = Ink,
    onSurface = Color(0xFFF5F6F8),
    surfaceVariant = InkSoft,
    onSurfaceVariant = Color(0xFFC8D2D9),
    outline = Color(0xFF40515B)
)

@Composable
fun AppDeckTheme(
    themeMode: ThemeMode,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}
