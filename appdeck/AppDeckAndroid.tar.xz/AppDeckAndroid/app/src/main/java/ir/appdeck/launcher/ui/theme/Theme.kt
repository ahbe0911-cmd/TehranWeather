package ir.appdeck.launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import ir.appdeck.launcher.model.ThemeMode

val Ink = Color(0xFF111827)
val InkSoft = Color(0xFF1F2937)
val Cream = Color(0xFFF7F9FC)
val Purple = Color(0xFF6C42F5)
val PurpleSoft = Color(0xFFEDE7FF)
val Green = Color(0xFF12B76A)
val Yellow = Color(0xFFF5B700)
val Coral = Color(0xFFFF6B5E)

private val LightColors = lightColorScheme(
    primary = Purple,
    onPrimary = Color.White,
    secondary = Color(0xFF1769FF),
    tertiary = Green,
    background = Cream,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFF2F4F7),
    onSurfaceVariant = Color(0xFF667085),
    outline = Color(0xFFD0D5DD)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9D83FF),
    onPrimary = Color(0xFF21105E),
    secondary = Color(0xFF78A9FF),
    tertiary = Green,
    background = Color(0xFF0B1018),
    onBackground = Color(0xFFF5F7FA),
    surface = Color(0xFF121A24),
    onSurface = Color(0xFFF5F7FA),
    surfaceVariant = InkSoft,
    onSurfaceVariant = Color(0xFFC7D0DB),
    outline = Color(0xFF475467)
)

@Composable
fun AppDeckTheme(
    themeMode: ThemeMode,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }

    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}
