package ir.appdeck.launcher.model

data class AppSection(
    val id: Long,
    val title: String,
    val color: SectionColor = SectionColor.BLUE,
    val icon: SectionIcon = SectionIcon.WORK,
    val packages: List<String> = emptyList()
)

data class InstalledApp(
    val packageName: String,
    val label: String
)

enum class SectionColor {
    BLUE,
    PURPLE,
    GREEN,
    ORANGE,
    PINK
}

enum class SectionIcon {
    WORK,
    SOCIAL,
    TOOLS,
    BANK,
    STAR,
    SCHOOL,
    SHOPPING,
    FAVORITE
}

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}
