package ir.appdeck.launcher.model

data class AppSection(
    val id: Long,
    val title: String,
    val packages: List<String> = emptyList()
)

data class CalendarNote(
    val id: Long,
    val dateKey: String,
    val text: String
)

data class InstalledApp(
    val packageName: String,
    val label: String
)

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}
