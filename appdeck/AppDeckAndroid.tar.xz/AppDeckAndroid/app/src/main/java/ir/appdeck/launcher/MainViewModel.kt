package ir.appdeck.launcher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.appdeck.launcher.data.AppStateRepository
import ir.appdeck.launcher.data.InstalledAppsRepository
import ir.appdeck.launcher.model.AppSection
import ir.appdeck.launcher.model.CalendarNote
import ir.appdeck.launcher.model.InstalledApp
import ir.appdeck.launcher.model.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val stateRepository = AppStateRepository(application)
    private val installedAppsRepository = InstalledAppsRepository(application)

    val sections: StateFlow<List<AppSection>> = stateRepository.sections.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    val notes: StateFlow<List<CalendarNote>> = stateRepository.notes.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    val themeMode: StateFlow<ThemeMode> = stateRepository.themeMode.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        ThemeMode.SYSTEM
    )

    private val _installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val installedApps: StateFlow<List<InstalledApp>> = _installedApps

    init {
        refreshInstalledApps()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _installedApps.value = installedAppsRepository.loadLauncherApps()
        }
    }

    fun addSection(title: String) = launch { stateRepository.addSection(title) }
    fun renameSection(id: Long, title: String) = launch { stateRepository.renameSection(id, title) }
    fun deleteSection(id: Long) = launch { stateRepository.deleteSection(id) }
    fun addPackage(sectionId: Long, packageName: String) = launch {
        stateRepository.addPackage(sectionId, packageName)
    }
    fun removePackage(sectionId: Long, packageName: String) = launch {
        stateRepository.removePackage(sectionId, packageName)
    }
    fun addNote(dateKey: String, text: String) = launch { stateRepository.addNote(dateKey, text) }
    fun deleteNote(id: Long) = launch { stateRepository.deleteNote(id) }
    fun setThemeMode(mode: ThemeMode) = launch { stateRepository.setThemeMode(mode) }

    private fun launch(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }
}
