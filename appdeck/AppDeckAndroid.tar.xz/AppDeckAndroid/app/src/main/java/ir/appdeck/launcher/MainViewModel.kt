package ir.appdeck.launcher

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import ir.appdeck.launcher.data.AppStateRepository
import ir.appdeck.launcher.data.InstalledAppsRepository
import ir.appdeck.launcher.model.AppSection
import ir.appdeck.launcher.model.InstalledApp
import ir.appdeck.launcher.model.SectionColor
import ir.appdeck.launcher.model.SectionIcon
import ir.appdeck.launcher.model.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val stateRepository = AppStateRepository(application)
    private val installedAppsRepository = InstalledAppsRepository(application)

    val sections: StateFlow<List<AppSection>> = stateRepository.sections.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        emptyList()
    )

    val themeMode: StateFlow<ThemeMode> = stateRepository.themeMode.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        ThemeMode.SYSTEM
    )

    private val _installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val installedApps: StateFlow<List<InstalledApp>> = _installedApps

    init {
        refreshInstalledApps()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            _installedApps.value = installedAppsRepository.loadLauncherApps()
        }
    }

    fun addSection(title: String, color: SectionColor, icon: SectionIcon) = launch {
        stateRepository.addSection(title, color, icon)
    }

    fun updateSection(id: Long, title: String, color: SectionColor, icon: SectionIcon) = launch {
        stateRepository.updateSection(id, title, color, icon)
    }

    fun deleteSection(id: Long) = launch { stateRepository.deleteSection(id) }

    fun addPackages(sectionId: Long, packages: Collection<String>) = launch {
        stateRepository.addPackages(sectionId, packages)
    }

    fun removePackage(sectionId: Long, packageName: String) = launch {
        stateRepository.removePackage(sectionId, packageName)
    }

    fun moveSection(id: Long, direction: Int) = launch {
        stateRepository.moveSection(id, direction)
    }

    fun movePackage(sectionId: Long, packageName: String, direction: Int) = launch {
        stateRepository.movePackage(sectionId, packageName, direction)
    }

    fun setThemeMode(mode: ThemeMode) = launch { stateRepository.setThemeMode(mode) }

    private fun launch(block: suspend () -> Unit) {
        viewModelScope.launch { block() }
    }
}
