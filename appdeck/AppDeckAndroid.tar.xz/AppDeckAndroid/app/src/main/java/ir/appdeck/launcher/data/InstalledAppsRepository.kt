package ir.appdeck.launcher.data

import android.content.Context
import android.content.Intent
import ir.appdeck.launcher.model.InstalledApp

class InstalledAppsRepository(private val context: Context) {
    fun loadLauncherApps(): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return context.packageManager
            .queryIntentActivities(intent, 0)
            .asSequence()
            .map { info ->
                InstalledApp(
                    packageName = info.activityInfo.packageName,
                    label = info.loadLabel(context.packageManager)?.toString().orEmpty()
                        .ifBlank { info.activityInfo.packageName }
                )
            }
            .filterNot { it.packageName == context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
            .toList()
    }
}
