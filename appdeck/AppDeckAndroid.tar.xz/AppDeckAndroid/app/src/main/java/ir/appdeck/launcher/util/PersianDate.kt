package ir.appdeck.launcher.util

import java.time.LocalDate

/**
 * Dependency-free Jalali/Gregorian conversion based on the well-known
 * break-year algorithm used by mature Jalali implementations.
 */
data class JalaliDate(val year: Int, val month: Int, val day: Int) {
    val key: String get() = "%04d-%02d-%02d".format(year, month, day)
}

data class GregorianDate(val year: Int, val month: Int, val day: Int)

object PersianDate {
    private val breaks = intArrayOf(
        -61, 9, 38, 199, 426, 686, 756, 818, 1111,
        1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178
    )

    fun today(): JalaliDate = fromGregorian(LocalDate.now())

    fun fromGregorian(date: LocalDate): JalaliDate =
        d2j(g2d(date.year, date.monthValue, date.dayOfMonth))

    fun toGregorian(jy: Int, jm: Int, jd: Int): GregorianDate = d2g(j2d(jy, jm, jd))

    fun daysInMonth(jy: Int, jm: Int): Int = when {
        jm in 1..6 -> 31
        jm in 7..11 -> 30
        jm == 12 -> if (isLeapYear(jy)) 30 else 29
        else -> throw IllegalArgumentException("Invalid Jalali month: $jm")
    }

    fun isLeapYear(jy: Int): Boolean = jalCal(jy).leap == 0

    private data class JalCal(val leap: Int, val gy: Int, val march: Int)

    private fun jalCal(jy: Int): JalCal {
        val bl = breaks.size
        val gy = jy + 621
        var leapJ = -14
        var jp = breaks[0]
        var jm = 0
        var jump = 0

        require(jy >= jp && jy < breaks[bl - 1]) { "Invalid Jalali year: $jy" }

        for (i in 1 until bl) {
            jm = breaks[i]
            jump = jm - jp
            if (jy < jm) break
            leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4)
            jp = jm
        }

        var n = jy - jp
        leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4)
        if (mod(jump, 33) == 4 && jump - n == 4) leapJ++

        val leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150
        val march = 20 + leapJ - leapG

        if (jump - n < 6) {
            n = n - jump + div(jump + 4, 33) * 33
        }

        var leap = mod(mod(n + 1, 33) - 1, 4)
        if (leap == -1) leap = 4

        return JalCal(leap = leap, gy = gy, march = march)
    }

    private fun j2d(jy: Int, jm: Int, jd: Int): Long {
        require(jm in 1..12) { "Invalid Jalali month: $jm" }
        require(jd in 1..daysInMonth(jy, jm)) { "Invalid Jalali day: $jd" }
        val r = jalCal(jy)
        return g2d(r.gy, 3, r.march) +
            (jm - 1) * 31L - div(jm, 7).toLong() * (jm - 7) + jd - 1
    }

    private fun d2j(jdn: Long): JalaliDate {
        val g = d2g(jdn)
        var jy = g.year - 621
        val r = jalCal(jy)
        val jdn1f = g2d(g.year, 3, r.march)
        var k = (jdn - jdn1f).toInt()

        if (k >= 0) {
            if (k <= 185) {
                return JalaliDate(jy, 1 + div(k, 31), mod(k, 31) + 1)
            }
            k -= 186
        } else {
            jy -= 1
            k += 179
            if (r.leap == 1) k += 1
        }

        return JalaliDate(jy, 7 + div(k, 30), mod(k, 30) + 1)
    }

    private fun g2d(gy: Int, gm: Int, gd: Int): Long {
        val shiftedYear = gy.toLong() + div(gm - 8, 6) + 100100L
        var d = divLong(shiftedYear * 1461L, 4L)
        d += div(153 * mod(gm + 9, 12) + 2, 5)
        d += gd - 34840408L
        d -= divLong(divLong(shiftedYear, 100L) * 3L, 4L)
        return d + 752L
    }

    private fun d2g(jdn: Long): GregorianDate {
        var j = 4L * jdn + 139361631L
        j += divLong(divLong(4L * jdn + 183187720L, 146097L) * 3L, 4L) * 4L - 3908L
        val i = divLong(modLong(j, 1461L), 4L) * 5L + 308L
        val gd = divLong(modLong(i, 153L), 5L).toInt() + 1
        val gm = modLong(divLong(i, 153L), 12L).toInt() + 1
        val gy = (divLong(j, 1461L) - 100100L + div(8 - gm, 6)).toInt()
        return GregorianDate(gy, gm, gd)
    }

    // Jalaali's reference algorithm uses truncation toward zero, matching Kotlin integer division.
    private fun div(a: Int, b: Int): Int = a / b
    private fun mod(a: Int, b: Int): Int = a % b
    private fun divLong(a: Long, b: Long): Long = a / b
    private fun modLong(a: Long, b: Long): Long = a % b
}

fun Int.toPersianDigits(): String = toString().toPersianDigits()

fun String.toPersianDigits(): String = buildString(length) {
    this@toPersianDigits.forEach { ch ->
        append(
            when (ch) {
                '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
                '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
                else -> ch
            }
        )
    }
}

val persianMonths = listOf(
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
)

val persianWeekdays = listOf(
    "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "جمعه", "شنبه", "یکشنبه"
)

fun JalaliDate.fullPersianText(gregorianDate: LocalDate = LocalDate.now()): String {
    val weekday = persianWeekdays[gregorianDate.dayOfWeek.value - 1]
    return "$weekday ${day.toPersianDigits()} ${persianMonths[month - 1]} ${year.toPersianDigits()}"
}
