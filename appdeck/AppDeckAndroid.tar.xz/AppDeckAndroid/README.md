# AppDeck

Persian RTL Android launcher dashboard with custom app sections, one-tap launch, Jalali date, Persian calendar notes, local persistence, Material 3 and GitHub Actions APK build.

See `README_FA.md` for the full Persian guide.
